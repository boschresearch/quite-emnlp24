% ID 0
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 1
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:00'), true).
% Evidence 1
evidence(cknd(2, '12:15'), true).
% Evidence 2
evidence(cknn(2, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 2
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Query
query(cknn(1, '12:00')).

% ID 3
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 4
% Evidences
% Evidence 0
evidence(cknd(6, '12:00'), true).
% Evidence 1
evidence(ckni(40, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 5
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknd(2, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(ckni(40, '12:00')).

% ID 6
% Evidences
% Evidence 0
evidence(cknn(2, '12:00'), true).
% Query
query(cknn(1, '12:15')).

% ID 7
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(2, '12:00'), true).
% Evidence 2
evidence(ckni(20, '12:00'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 8
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(2, '12:15'), true).
% Evidence 2
evidence(cknn(2, '12:00'), true).
% Evidence 3
evidence(cknd(6, '12:00'), true).
% Query
query(ckni(20, '12:00')).

% ID 9
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 10
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 11
% Evidences
% Evidence 0
evidence(cknn(2, '12:00'), true).
% Query
query(cknd(4, '12:00')).

% ID 12
% Evidences
% Evidence 0
evidence(cknd(2, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 13
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Evidence 1
evidence(ckni(30, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 14
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:00'), true).
% Evidence 2
evidence(cknd(2, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 15
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(2, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Evidence 3
evidence(cknd(4, '12:00'), true).
% Query
query(ckni(40, '12:00')).

% ID 16
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(ckni(30, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 17
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 18
% Evidences
% Evidence 0
evidence(cknd(2, '12:00'), true).
% Query
query(cknd(6, '12:15')).

% ID 19
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 20
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:00'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 21
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(ckni(40, '12:00'), true).
% Evidence 2
evidence(cknd(2, '12:00'), true).
% Query
query(cknn(0.5, '12:00')).
