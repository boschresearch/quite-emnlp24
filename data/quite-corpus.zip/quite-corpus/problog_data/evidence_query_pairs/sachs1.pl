% ID 0
% Evidences
% Evidence 0
evidence(akt(average), true).
% Evidence 1
evidence(erk(low), true).
% Query
query(jnk(high)).

% ID 1
% Evidences
% Evidence 0
evidence(raf(average), true).
% Evidence 1
evidence(pkc(average), true).
% Evidence 2
evidence(akt(average), true).
% Evidence 3
evidence(jnk(average), true).
% Evidence 4
evidence(mek(average), true).
% Evidence 5
evidence(pka(average), true).
% Evidence 6
evidence(p38(average), true).
% Query
query(erk(low)).

% ID 2
% Evidences
% Evidence 0
evidence(mek(low), true).
% Query
query(erk(average)).

% ID 3
% Evidences
% Evidence 0
evidence(jnk(low), true).
% Evidence 1
evidence(erk(low), true).
% Evidence 2
evidence(p38(low), true).
% Evidence 3
evidence(pka(high), true).
% Evidence 4
evidence(raf(low), true).
% Query
query(pkc(low)).

% ID 4
% Evidences
% Evidence 0
evidence(akt(high), true).
% Evidence 1
evidence(pkc(low), true).
% Query
query(jnk(average)).

% ID 5
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pkc(low), true).
% Evidence 2
evidence(pka(low), true).
% Evidence 3
evidence(jnk(low), true).
% Evidence 4
evidence(akt(high), true).
% Evidence 5
evidence(erk(average), true).
% Evidence 6
evidence(mek(high), true).
% Query
query(raf(average)).

% ID 6
% Evidences
% Evidence 0
evidence(pkc(high), true).
% Query
query(pkc(high)).

% ID 7
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pkc(low), true).
% Evidence 2
evidence(pka(low), true).
% Evidence 3
evidence(jnk(low), true).
% Evidence 4
evidence(akt(high), true).
% Evidence 5
evidence(erk(average), true).
% Evidence 6
evidence(mek(high), true).
% Query
query(pka(high)).

% ID 8
% Evidences
% Evidence 0
evidence(mek(high), true).
% Evidence 1
evidence(pka(low), true).
% Evidence 2
evidence(raf(average), true).
% Evidence 3
evidence(jnk(high), true).
% Evidence 4
evidence(pkc(average), true).
% Query
query(p38(average)).

% ID 9
% Evidences
% Evidence 0
evidence(mek(high), true).
% Query
query(raf(high)).
