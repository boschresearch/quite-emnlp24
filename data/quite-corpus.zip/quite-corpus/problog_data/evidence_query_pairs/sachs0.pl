% ID 0
% Evidences
% Evidence 0
evidence(pip2(high), true).
% Query
query(pip3(average)).

% ID 1
% Evidences
% Evidence 0
evidence(plcg(low), true).
% Query
query(pip3(low)).

% ID 2
% Evidences
% Evidence 0
evidence(plcg(low), true).
% Evidence 1
evidence(pip3(low), true).
% Query
query(pip2(average)).

% ID 3
% Evidences
% Evidence 0
evidence(pip3(high), true).
% Query
query(plcg(high)).

% ID 4
% Evidences
% Evidence 0
evidence(pip2(high), true).
% Evidence 1
evidence(plcg(low), true).
% Query
query(pip3(low)).

% ID 5
% Evidences
% Evidence 0
evidence(plcg(low), true).
% Query
query(pip3(average)).

% ID 6
% Evidences
% Evidence 0
evidence(plcg(high), true).
% Query
query(pip3(high)).

% ID 7
% Evidences
% Evidence 0
evidence(pip2(low), true).
% Query
query(pip3(average)).

% ID 8
% Evidences
% Evidence 0
evidence(pip3(high), true).
% Query
query(plcg(average)).

% ID 9
% Evidences
% Evidence 0
evidence(plcg(average), true).
% Query
query(pip3(low)).

% ID 10
% Evidences
% Evidence 0
evidence(pip3(low), true).
% Query
query(plcg(high)).

% ID 11
% Evidences
% Evidence 0
evidence(pip2(low), true).
% Evidence 1
evidence(pip3(high), true).
% Query
query(plcg(average)).

% ID 12
% Evidences
% Evidence 0
evidence(pip3(low), true).
% Evidence 1
evidence(plcg(low), true).
% Query
query(pip2(average)).

% ID 13
% Evidences
% Evidence 0
evidence(pip2(low), true).
% Evidence 1
evidence(pip3(low), true).
% Query
query(plcg(high)).

% ID 14
% Evidences
% Evidence 0
evidence(plcg(high), true).
% Query
query(pip3(high)).

% ID 15
% Evidences
% Evidence 0
evidence(pip2(high), true).
% Evidence 1
evidence(plcg(average), true).
% Query
query(pip3(low)).

% ID 16
% Evidences
% Evidence 0
evidence(plcg(average), true).
% Query
query(pip3(low)).

% ID 17
% Evidences
% Evidence 0
evidence(plcg(average), true).
% Query
query(pip2(high)).

% ID 18
% Evidences
% Evidence 0
evidence(pip3(average), true).
% Query
query(plcg(average)).

% ID 19
% Evidences
% Evidence 0
evidence(pip3(low), true).
% Evidence 1
evidence(pip2(average), true).
% Query
query(plcg(low)).
