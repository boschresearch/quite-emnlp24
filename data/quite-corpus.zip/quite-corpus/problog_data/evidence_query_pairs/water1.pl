% ID 0
% Evidences
% Evidence 0
evidence(cnon(4, '12:00'), true).
% Query
query(cbodn(15, '12:00')).

% ID 1
% Evidences
% Evidence 0
evidence(cbodn(10, '12:15'), true).
% Query
query(cbodn(20, '12:00')).

% ID 2
% Evidences
% Evidence 0
evidence(cnon(4, '12:00'), true).
% Query
query(cbodd(25, '12:00')).

% ID 3
% Evidences
% Evidence 0
evidence(cbodn(10, '12:15'), true).
% Query
query(cnon(6, '12:00')).

% ID 4
% Evidences
% Evidence 0
evidence(cbodn(15, '12:15'), true).
% Evidence 1
evidence(cbodn(10, '12:00'), true).
% Query
query(cbodd(20, '12:00')).

% ID 5
% Evidences
% Evidence 0
evidence(cnon(4, '12:00'), true).
% Evidence 1
evidence(cbodn(15, '12:15'), true).
% Query
query(cbodn(20, '12:00')).

% ID 6
% Evidences
% Evidence 0
evidence(cbodn(10, '12:15'), true).
% Query
query(cnon(6, '12:00')).

% ID 7
% Evidences
% Evidence 0
evidence(cbodn(10, '12:00'), true).
% Query
query(cbodn(15, '12:15')).

% ID 8
% Evidences
% Evidence 0
evidence(cbodn(10, '12:15'), true).
% Query
query(cnon(4, '12:00')).

% ID 9
% Evidences
% Evidence 0
evidence(cnon(4, '12:00'), true).
% Query
query(cbodn(5, '12:00')).

% ID 10
% Evidences
% Evidence 0
evidence(cbodn(15, '12:15'), true).
% Query
query(cnon(4, '12:00')).

% ID 11
% Evidences
% Evidence 0
evidence(cbodn(20, '12:00'), true).
% Evidence 1
evidence(cbodd(25, '12:00'), true).
% Evidence 2
evidence(cnon(10, '12:00'), true).
% Query
query(cbodn(15, '12:15')).

% ID 12
% Evidences
% Evidence 0
evidence(cbodn(10, '12:00'), true).
% Evidence 1
evidence(cbodd(15, '12:00'), true).
% Evidence 2
evidence(cbodn(15, '12:15'), true).
% Query
query(cnon(2, '12:00')).
