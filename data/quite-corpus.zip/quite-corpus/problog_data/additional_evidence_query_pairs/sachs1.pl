% ID 10
% Evidences
% Evidence 0
evidence(erk(high), true).
% Query
query(akt(high)).

% ID 11
% Evidences
% Evidence 0
evidence(jnk(high), true).
% Query
query(akt(high)).

% ID 12
% Evidences
% Evidence 0
evidence(mek(high), true).
% Query
query(akt(average)).

% ID 13
% Evidences
% Evidence 0
evidence(p38(low), true).
% Query
query(akt(average)).

% ID 14
% Evidences
% Evidence 0
evidence(p38(average), true).
% Query
query(akt(average)).

% ID 15
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Query
query(akt(low)).

% ID 16
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Query
query(akt(average)).

% ID 17
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Query
query(akt(average)).

% ID 18
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(low), true).
% Query
query(akt(average)).

% ID 19
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Query
query(akt(high)).

% ID 20
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(pka(low), true).
% Query
query(akt(average)).

% ID 21
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(pka(average), true).
% Query
query(akt(low)).

% ID 22
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(pka(high), true).
% Query
query(akt(high)).

% ID 23
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(pkc(low), true).
% Query
query(akt(low)).

% ID 24
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(pkc(high), true).
% Query
query(akt(low)).

% ID 25
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(raf(low), true).
% Query
query(akt(low)).

% ID 26
% Evidences
% Evidence 0
evidence(jnk(average), true).
% Evidence 1
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 27
% Evidences
% Evidence 0
evidence(jnk(high), true).
% Evidence 1
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 28
% Evidences
% Evidence 0
evidence(mek(high), true).
% Evidence 1
evidence(p38(average), true).
% Query
query(akt(average)).

% ID 29
% Evidences
% Evidence 0
evidence(mek(high), true).
% Evidence 1
evidence(pka(average), true).
% Query
query(akt(average)).

% ID 30
% Evidences
% Evidence 0
evidence(mek(low), true).
% Evidence 1
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 31
% Evidences
% Evidence 0
evidence(mek(high), true).
% Evidence 1
evidence(raf(high), true).
% Query
query(akt(high)).

% ID 32
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pka(low), true).
% Query
query(akt(low)).

% ID 33
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pka(average), true).
% Query
query(akt(low)).

% ID 34
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pka(high), true).
% Query
query(akt(low)).

% ID 35
% Evidences
% Evidence 0
evidence(p38(average), true).
% Evidence 1
evidence(pka(average), true).
% Query
query(akt(average)).

% ID 36
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pkc(low), true).
% Query
query(akt(high)).

% ID 37
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(pkc(high), true).
% Query
query(akt(high)).

% ID 38
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(raf(low), true).
% Query
query(akt(high)).

% ID 39
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(raf(average), true).
% Query
query(akt(low)).

% ID 40
% Evidences
% Evidence 0
evidence(p38(low), true).
% Evidence 1
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 41
% Evidences
% Evidence 0
evidence(pka(low), true).
% Evidence 1
evidence(raf(low), true).
% Query
query(akt(average)).

% ID 42
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(mek(low), true).
% Query
query(akt(average)).

% ID 43
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(mek(average), true).
% Query
query(akt(low)).

% ID 44
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(mek(high), true).
% Query
query(akt(high)).

% ID 45
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(mek(low), true).
% Query
query(akt(low)).

% ID 46
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(mek(average), true).
% Query
query(akt(high)).

% ID 47
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(mek(high), true).
% Query
query(akt(average)).

% ID 48
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(mek(high), true).
% Query
query(akt(high)).

% ID 49
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(p38(low), true).
% Query
query(akt(low)).

% ID 50
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(p38(average), true).
% Query
query(akt(high)).

% ID 51
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(p38(high), true).
% Query
query(akt(low)).

% ID 52
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(p38(average), true).
% Query
query(akt(low)).

% ID 53
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(p38(high), true).
% Query
query(akt(high)).

% ID 54
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(p38(average), true).
% Query
query(akt(average)).

% ID 55
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(p38(high), true).
% Query
query(akt(high)).

% ID 56
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(pka(low), true).
% Query
query(akt(average)).

% ID 57
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(pka(low), true).
% Query
query(akt(low)).

% ID 58
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(pka(average), true).
% Query
query(akt(high)).

% ID 59
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(pka(average), true).
% Query
query(akt(high)).

% ID 60
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(pka(high), true).
% Query
query(akt(low)).

% ID 61
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(pkc(low), true).
% Query
query(akt(high)).

% ID 62
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(pkc(average), true).
% Query
query(akt(high)).

% ID 63
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(low)).

% ID 64
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(pkc(low), true).
% Query
query(akt(low)).

% ID 65
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(pkc(average), true).
% Query
query(akt(low)).

% ID 66
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(pkc(low), true).
% Query
query(akt(low)).

% ID 67
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(pkc(average), true).
% Query
query(akt(high)).

% ID 68
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(high)).

% ID 69
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(raf(low), true).
% Query
query(akt(high)).

% ID 70
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(raf(average), true).
% Query
query(akt(low)).

% ID 71
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(low), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 72
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(raf(low), true).
% Query
query(akt(low)).

% ID 73
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(raf(average), true).
% Query
query(akt(average)).

% ID 74
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(average), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 75
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(raf(average), true).
% Query
query(akt(low)).

% ID 76
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(jnk(high), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(high)).

% ID 77
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Evidence 2
evidence(p38(high), true).
% Query
query(akt(average)).

% ID 78
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(p38(low), true).
% Query
query(akt(low)).

% ID 79
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(p38(high), true).
% Query
query(akt(high)).

% ID 80
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Evidence 2
evidence(pka(high), true).
% Query
query(akt(average)).

% ID 81
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(pka(low), true).
% Query
query(akt(high)).

% ID 82
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(pka(high), true).
% Query
query(akt(high)).

% ID 83
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(low), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(high)).

% ID 84
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Evidence 2
evidence(pkc(low), true).
% Query
query(akt(high)).

% ID 85
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(average)).

% ID 86
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(low)).

% ID 87
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(low), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(high)).

% ID 88
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(average), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(average)).

% ID 89
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(mek(high), true).
% Evidence 2
evidence(raf(high), true).
% Query
query(akt(high)).

% ID 90
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(average), true).
% Evidence 2
evidence(pka(low), true).
% Query
query(akt(low)).

% ID 91
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Evidence 2
evidence(pka(low), true).
% Query
query(akt(average)).

% ID 92
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Evidence 2
evidence(pka(high), true).
% Query
query(akt(average)).

% ID 93
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Evidence 2
evidence(pkc(low), true).
% Query
query(akt(low)).

% ID 94
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Evidence 2
evidence(pkc(average), true).
% Query
query(akt(high)).

% ID 95
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(high), true).
% Evidence 2
evidence(pkc(high), true).
% Query
query(akt(low)).

% ID 96
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(low), true).
% Evidence 2
evidence(raf(low), true).
% Query
query(akt(average)).

% ID 97
% Evidences
% Evidence 0
evidence(erk(high), true).
% Evidence 1
evidence(p38(average), true).
% Evidence 2
evidence(raf(low), true).
% Query
query(akt(high)).
