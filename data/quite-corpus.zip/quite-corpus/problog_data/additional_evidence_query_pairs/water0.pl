% ID 22
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Query
query(ckni(40, '12:00')).

% ID 23
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Query
query(ckni(20, '12:00')).

% ID 24
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 25
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 26
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 27
% Evidences
% Evidence 0
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 28
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(ckni(30, '12:00')).

% ID 29
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 30
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 31
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 32
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 33
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 34
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 35
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 36
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 37
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 38
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 39
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 40
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 41
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 42
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 43
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 44
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 45
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 46
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 47
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 48
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 49
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 50
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(20, '12:00')).

% ID 51
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 52
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 53
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 54
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(30, '12:00')).

% ID 55
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 56
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(ckni(40, '12:00')).

% ID 57
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Query
query(cknd(6, '12:00')).

% ID 58
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Query
query(cknd(6, '12:00')).

% ID 59
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Query
query(cknd(4, '12:00')).

% ID 60
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(4, '12:00')).

% ID 61
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 62
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 63
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 64
% Evidences
% Evidence 0
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 65
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(6, '12:00')).

% ID 66
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(6, '12:00')).

% ID 67
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(4, '12:00')).

% ID 68
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 69
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 70
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 71
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 72
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 73
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 74
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 75
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 76
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 77
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 78
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 79
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 80
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 81
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 82
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 83
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 84
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 85
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 86
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 87
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 88
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 89
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 90
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 91
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 92
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 93
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 94
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 95
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 96
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 97
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 98
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 99
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 100
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 101
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 102
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 103
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 104
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 105
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 106
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 107
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 108
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 109
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 110
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 111
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 112
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 113
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 114
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 115
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 116
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 117
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 118
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 119
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 120
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:00')).

% ID 121
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 122
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 123
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 124
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 125
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 126
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:00')).

% ID 127
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:00')).

% ID 128
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 129
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Query
query(cknn(2, '12:00')).

% ID 130
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 131
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 132
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 133
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 134
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 135
% Evidences
% Evidence 0
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 136
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(1, '12:00')).

% ID 137
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(1, '12:00')).

% ID 138
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(2, '12:00')).

% ID 139
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 140
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 141
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 142
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 143
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 144
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 145
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 146
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 147
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 148
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 149
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 150
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 151
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 152
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 153
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 154
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 155
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 156
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 157
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 158
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 159
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 160
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 161
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 162
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 163
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 164
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 165
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 166
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 167
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 168
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 169
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 170
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 171
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 172
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 173
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 174
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 175
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 176
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 177
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 178
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 179
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 180
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 181
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 182
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 183
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 184
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 185
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 186
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 187
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 188
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 189
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 190
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 191
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 192
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 193
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 194
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 195
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 196
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(0.5, '12:00')).

% ID 197
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknn(2, '12:00')).

% ID 198
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknn(1, '12:00')).

% ID 199
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Query
query(cknd(2, '12:15')).

% ID 200
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 201
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 202
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 203
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(2, '12:15')).

% ID 204
% Evidences
% Evidence 0
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 205
% Evidences
% Evidence 0
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 206
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknd(2, '12:15')).

% ID 207
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 208
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 209
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(6, '12:15')).

% ID 210
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(2, '12:15')).

% ID 211
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(2, '12:15')).

% ID 212
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 213
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 214
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 215
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 216
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 217
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 218
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 219
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 220
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 221
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 222
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 223
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 224
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(4, '12:15')).

% ID 225
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknd(6, '12:15')).

% ID 226
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 227
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 228
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 229
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 230
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 231
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 232
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 233
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 234
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 235
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 236
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 237
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 238
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 239
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 240
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 241
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 242
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 243
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(4, '12:15')).

% ID 244
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(0.5, '12:15'), true).
% Query
query(cknd(2, '12:15')).

% ID 245
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknn(1, '12:15'), true).
% Query
query(cknd(6, '12:15')).

% ID 246
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Query
query(cknn(1, '12:15')).

% ID 247
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 248
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 249
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 250
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 251
% Evidences
% Evidence 0
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 252
% Evidences
% Evidence 0
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 253
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(1, '12:15')).

% ID 254
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 255
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 256
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 257
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 258
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 259
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 260
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 261
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 262
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 263
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 264
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 265
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 266
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 267
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 268
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 269
% Evidences
% Evidence 0
evidence(cknn(1, '12:00'), true).
% Evidence 1
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 270
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 271
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(1, '12:15')).

% ID 272
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Query
query(cknn(2, '12:15')).

% ID 273
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 274
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 275
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 276
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 277
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 278
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 279
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 280
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 281
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 282
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 283
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 284
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 285
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 286
% Evidences
% Evidence 0
evidence(cknd(4, '12:00'), true).
% Evidence 1
evidence(cknn(1, '12:00'), true).
% Evidence 2
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 287
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(2, '12:15')).

% ID 288
% Evidences
% Evidence 0
evidence(ckni(20, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 289
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(1, '12:15')).

% ID 290
% Evidences
% Evidence 0
evidence(ckni(30, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknd(6, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).

% ID 291
% Evidences
% Evidence 0
evidence(ckni(40, '12:00'), true).
% Evidence 1
evidence(cknd(4, '12:00'), true).
% Evidence 2
evidence(cknn(1, '12:00'), true).
% Evidence 3
evidence(cknd(4, '12:15'), true).
% Query
query(cknn(0.5, '12:15')).
